const S_URL = 'https://kijosedzdnpjgtrhrvbu.supabase.co';
const S_KEY = 'sb_publishable_WnFHswDh1LLnoR61Sl2UXg_Iz6IKQc5';
const _supabase = supabase.createClient(S_URL, S_KEY);
